(function(e,t){Object.defineProperty(e,Symbol.toStringTag,{value:`Module`});var n=`https://open.spotify.com/`,r=[`track`,`playlist`,`episode`,`album`],i=function(e){return e===`playlist`||e===`album`},a=`(function () {
	if (window.__spotifyPreviewClean) return;
	window.__spotifyPreviewClean = true;
	var done = new WeakSet();
	function text(el) { return (el.textContent || '').replace(/\\s+/g, ' ').trim(); }
	function dismiss(button) {
		var el = button;
		for (var i = 0; el && el !== document.body && i < 10; i++, el = el.parentElement) {
			var close = el.querySelector('[aria-label*="lose" i],[data-testid*="close" i],[title*="lose" i]');
			if (close && close !== button && !button.contains(close)) { close.click(); return true; }
		}
		return false;
	}
	function scan() {
		var els = document.querySelectorAll('a,button,[role="button"]');
		for (var i = 0; i < els.length; i++) {
			var el = els[i];
			if (done.has(el) || !/^get spotify$/i.test(text(el))) continue;
			done.add(el);
			if (!dismiss(el)) el.style.setProperty('display', 'none', 'important');
		}
	}
	new MutationObserver(scan).observe(document, { childList: true, subtree: true });
	scan();
})();
true;`,o=/^Symbol\(react\.(forward_ref|memo|lazy)\)$/,s=function(e){if(typeof e==`function`)return!0;if(typeof e!=`object`||!e)return!1;try{return o.test(String(e.$$typeof))}catch{return!1}};function c(e){if(!valenced.modules.metro.isModuleExportBad(e)){var t=e;try{return[t.default?.render,t.WebView?.render,t.default,t.WebView,t].find(s)}catch{return}}}var l=400,u=valenced.modules.finders.filters.createFilterGenerator(function([e,t],n,r,i){if(i)return valenced.modules.metro.isModuleExportBad(r)||typeof r!=`object`&&typeof r!=`function`?!1:`WebView`in r&&c(r)!==void 0;var a=valenced.modules.metro.getModuleDependencies(n);if(!a||a.length>4||!a.some(function(n){var r=valenced.modules.metro.getModuleDependencies(n);return!r||r.length<4||r.length>24?!1:e||t.native!==void 0&&r.includes(t.native)}))return!1;if(e){if(t.loose>=l)return!1;t.loose++}return!0},function([e]){return`spotify-preview.webview(${e?`loose`:`strict`})`},valenced.modules.finders.filters.FilterScopes.Uninitialized|valenced.modules.finders.filters.FilterScopes.Initialized);function d(e){var[,t]=valenced.modules.finders.lookupModule(valenced.modules.finders.filters.withProps(`AppRegistry`,`Linking`));e.native=t;for(var n of[!1,!0])if(n||t!==void 0){var r=c(valenced.modules.finders.lookupModule(u(n,e),{returnNamespace:!0})[0]);if(r)return r}}function f({WebView:e,href:r,type:o}){var{colors:c,internal:l}=valenced.discord.common.tokens.Tokens.default,u=c.MODAL_BACKGROUND?l.resolveSemanticColor(valenced.discord.flux.Stores.ThemeStore.theme,c.MODAL_BACKGROUND):`transparent`,d=s(valenced.externals.Gorhom.BottomSheet?.BottomSheetScrollView)?valenced.externals.Gorhom.BottomSheet.BottomSheetScrollView:valenced.react.ReactNative.ScrollView;return/*#__PURE__*/ (0,t.jsx)(valenced.discord.design.Design.ActionSheet,{children:/*#__PURE__*/ (0,t.jsx)(d,{contentContainerStyle:{marginBottom:100},children:/*#__PURE__*/ (0,t.jsx)(e,{injectedJavaScript:a,source:{uri:r.replace(n,`${n}embed/`)},style:{marginTop:20,backgroundColor:u,height:i(o)?352:152,width:`100%`},nestedScrollEnabled:i(o)})})})}return e.default=plugin({start({cleanup:e,plugin:i}){var a={loose:0},o,s=0;function c(e){if(typeof e!=`string`||!e.startsWith(n))return!1;var c=e.split(`/`)[3];if(!r.includes(c))return!1;if(!o)try{o=d(a)}catch(e){i.reportError(e)}if(!o)return!1;var l=Date.now();if(l-s<1e3)return!0;s=l;var u=o;return valenced.discord.actions.ActionSheetActionCreators.openLazy(Promise.resolve({default:function(){return/*#__PURE__*/ (0,t.jsx)(f,{WebView:u,href:e,type:c})}}),`SpotifyPreview`,{}),!0}e(valenced.modules.finders.getModules(valenced.modules.finders.filters.withProps(`handleClick`),function(t){e(valenced.patcher.instead(t,`handleClick`,function(e,t){if(!c(e[0]?.href))return Reflect.apply(t,this,e)}))})),e(valenced.patcher.instead(valenced.react.ReactNative.Linking,`openURL`,function(e,t){return c(e[0])?Promise.resolve(!0):Reflect.apply(t,valenced.react.ReactNative.Linking,e)}))}}),e})({},valenced.react.ReactJSXRuntime);